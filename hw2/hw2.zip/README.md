# Fuzzy, Evolutionary and Neuro-computing
---
## HW1
---
https://www.fer.unizg.hr/predmet/nenr
