class Mutation
  def mutate(individual)
    raise NotImplementedError
  end
end