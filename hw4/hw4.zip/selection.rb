class Selection
  def select_individuals(population)
    raise NotImplementedError
  end
end